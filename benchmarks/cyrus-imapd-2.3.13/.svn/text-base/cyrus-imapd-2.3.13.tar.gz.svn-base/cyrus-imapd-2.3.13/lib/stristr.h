/* stristr.h -- locate a substring case-insensitively
 */

/* $Id: stristr.h,v 1.2 2002/05/25 19:57:47 leg Exp $ */

#ifndef INCLUDED_STRISTR_H
#define INCLUDED_STRISTR_H

extern char *stristr(const char *haystack, const char *needle);

#endif /* INCLUDED_STRISTR_H */
